# Design System Strategy: The Serene Architect

## 1. Overview & Creative North Star
The "Serene Architect" is the Creative North Star for this design system. For the Spanish freelancer, the administrative world is often chaotic and high-friction. This system rejects the "cold corporate" dashboard in favor of a **High-End Editorial** experience that feels like a premium workspace.

We break the "template" look by prioritizing **intentional asymmetry** and **tonal depth**. Rather than a rigid grid of boxed-in data, we use expansive breathing room and overlapping surfaces to create a sense of "The Digital Curator." The interface should feel less like a database and more like a personal assistant—organized, quiet, and profoundly under control.

## 2. Colors & Surface Philosophy
The palette is rooted in a spectrum of blues to evoke stability and peace of mind. However, the execution must move beyond flat fills.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning or layout containment.
Boundaries must be defined solely through:
*   **Background Color Shifts:** A `surface-container-low` (#f1f3ff) section sitting on a `surface` (#f9f9ff) background.
*   **Tonal Transitions:** Using the subtle delta between `surface-variant` (#d8e2fe) and `surface-container-highest` (#d8e2fe).

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of fine paper. 
*   **Base:** `surface` (#f9f9ff)
*   **Structural Sections:** `surface-container-low` (#f1f3ff)
*   **Primary Interaction Cards:** `surface-container-lowest` (#ffffff) to provide a "pop" of clean white against the icy backgrounds.
*   **Contextual Overlays:** `surface-container-high` (#e0e8ff)

### The "Glass & Gradient" Rule
To elevate the experience, use **Glassmorphism** for floating elements (like navigation bars or action modals). 
*   **Formula:** `surface` color at 70% opacity + `backdrop-blur: 12px`.
*   **Signature Textures:** Use subtle linear gradients for Hero CTAs (e.g., `primary` #00629e to `primary-container` #63adf2 at 135°) to add "soul" and depth that flat hex codes cannot achieve.

## 3. Typography
The system uses a dual-font pairing to balance professional authority with approachable warmth.

*   **Display & Headlines (Manrope):** Our "Editorial" voice. Use `display-lg` (3.5rem) with tighter letter-spacing (-0.02em) for high-impact financial summaries. The geometric yet rounded nature of Manrope feels modern and bespoke.
*   **Body & UI (Inter):** Our "Functional" voice. Used for `label-md` and `label-sm`. Inter’s high x-height ensures maximum readability for complex tax data and line items.
*   **Hierarchy Note:** Use `headline-md` (1.75rem) in `on_surface_variant` (#404750) to create a sophisticated, low-contrast look that reduces cognitive eye-strain during long work sessions.

## 4. Elevation & Depth
We eschew "material" shadows for **Tonal Layering**.

*   **The Layering Principle:** Depth is achieved by stacking. Place a `surface-container-lowest` (#ffffff) card on a `surface-container-low` (#f1f3ff) background. This creates a soft, natural lift without a single drop shadow.
*   **Ambient Shadows:** When an element must float (e.g., a floating action button or a dropdown), use a "Sunlit Shadow":
    *   `box-shadow: 0 12px 32px -4px rgba(84, 94, 117, 0.08);`
    *   The shadow is tinted with `blue-slate` (#545E75) rather than black to maintain the cool, airy atmosphere.
*   **The Ghost Border Fallback:** If accessibility requires a stroke (e.g., in high-contrast mode), use a "Ghost Border": `outline-variant` (#c0c7d2) at 20% opacity. Never use 100% opaque borders.

## 5. Components

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary-container`) with `on_primary` (#ffffff) text. Roundedness: `full` (9999px) for a "pill" shape that feels friendly.
*   **Secondary:** `surface-container-highest` (#d8e2fe) fill with `primary` (#00629e) text. No border.
*   **Tertiary:** Text-only using `primary` (#00629e) with an underline that appears only on hover.

### Input Fields & Finance Inputs
*   **State:** Default state uses `surface-container-lowest` (#ffffff) with a 2px `outline-variant` (#c0c7d2) at 10% opacity. 
*   **Focus State:** The border transitions to `primary` (#00629e) with a subtle `primary-fixed` (#cfe5ff) outer glow (4px spread).
*   **Typography:** Large input text using `title-lg` (1.375rem) for currency values to emphasize control and precision.

### Cards & Financial Lists
*   **The "No-Divider" Rule:** Forbid the use of horizontal lines between list items. Instead, use `8` (2rem) vertical spacing from the Spacing Scale or alternating background tints (`surface` vs `surface-container-low`).
*   **Roundedness:** All cards must use `xl` (1.5rem) corner radius to soften the "financial tool" feel.

### Data Visualization (The "Clarity" Suite)
*   **Charts:** Use `primary` (#00629e), `tertiary` (#3d627f), and `secondary-container` (#bad7fd). Avoid harsh reds/greens unless indicating a critical error. Use "Cool Sky" (#63ADF2) for growth trends to maintain the "Peace of Mind" brand promise.

## 6. Do’s and Don’ts

### Do
*   **Do** use asymmetrical layouts (e.g., a wide left column for data and a narrow right column for "Insights").
*   **Do** use `display-sm` for empty-state messaging to make the app feel like a premium editorial magazine.
*   **Do** prioritize "White Space as a Feature." If a screen feels cluttered, increase spacing to the next tier in the scale (e.g., move from `8` to `12`).

### Don’t
*   **Don’t** use 1px solid borders to separate sections. It creates visual "noise" and feels like legacy software.
*   **Don’t** use pure black (#000000) for text. Use `on_surface` (#111b2f) to maintain the deep blue tonal integrity.
*   **Don’t** use "Sharp" corners. Every element must have a minimum of `sm` (0.25rem) roundedness to avoid a "cold corporate" feel.